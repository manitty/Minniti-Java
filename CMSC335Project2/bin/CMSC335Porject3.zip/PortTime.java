//File name: Thing.java
//Author: Paul Minniti
//Date: 4 June 2017

public class PortTime {
   
	//instance variables
	int time;

	//constructor
    public PortTime(int time) {
        this.time = time;
    }

    //Getter & Setter Methods
    public int getTime() {
        return time;
    }

    public void setTime(int time) {
        this.time = time;
    }
    
    
}
