public class SortMain {

 
    public static void main(String[] args) throws Exception{
        int[] sizes = {100, 200, 300, 400, 500, 600, 700, 800, 900, 1000} ;
        BenchmarkSorts bSorts = new BenchmarkSorts(sizes);
      }
  
}