public class UnsortedException extends Exception{
  
    public UnsortedException(){
   
    }
  
    public UnsortedException (String message){
        super(message);
    }
  
}


